//
//  ViewController.h
//  HG_ShoppingMall
//
//  Created by Lindashuai on 2019/11/25.
//  Copyright © 2019 Lindashuai. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

