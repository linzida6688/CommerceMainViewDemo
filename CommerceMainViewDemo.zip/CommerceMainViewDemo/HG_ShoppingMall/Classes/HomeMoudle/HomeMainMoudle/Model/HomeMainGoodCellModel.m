//
//  HomeMainGoodCellModel.m
//  HG_ShoppingMall
//
//  Created by Lindashuai on 2019/12/7.
//  Copyright © 2019 Lindashuai. All rights reserved.
//

#import "HomeMainGoodCellModel.h"

@implementation HomeMainGoodCellModel

+ (NSMutableArray<HomeMainGoodCellModel *> *)getHomeMainGoodArr {
    NSMutableArray<HomeMainGoodCellModel *> *listArr = [NSMutableArray<HomeMainGoodCellModel *> array];
    NSArray *array = [NSArray arrayWithObjects:@{@"goodImage":@"icon_winebottle",@"goodType":@"1",@"goodName":@"tableViewCell 0",@"saleCount":@"12315",@"hasCount":@" 1546",@"goodPay":@"238",@"goodTruePay":@"238",@"isSelect":@"0"},@{@"goodImage":@"icon_winebottle",@"goodType":@"2",@"goodName":@"tableViewCell 1",@"saleCount":@"12315",@"hasCount":@" 1546",@"goodPay":@"238",@"goodTruePay":@"238",@"isSelect":@"0"},@{@"goodImage":@"icon_winebottle",@"goodType":@"3",@"goodName":@"tableViewCell 2",@"saleCount":@"12315",@"hasCount":@" 0",@"goodPay":@"238",@"goodTruePay":@"238",@"isSelect":@"0"},@{@"goodImage":@"icon_winebottle",@"goodType":@"3",@"goodName":@"tableViewCell 3",@"saleCount":@"12315",@"hasCount":@" 0",@"goodPay":@"238",@"goodTruePay":@"238",@"isSelect":@"0"},@{@"goodImage":@"icon_winebottle",@"goodType":@"3",@"goodName":@"tableViewCell 4",@"saleCount":@"12315",@"hasCount":@" 0",@"goodPay":@"238",@"goodTruePay":@"238",@"isSelect":@"0"},@{@"goodImage":@"icon_winebottle",@"goodType":@"3",@"goodName":@"tableViewCell 5",@"saleCount":@"12315",@"hasCount":@" 0",@"goodPay":@"238",@"goodTruePay":@"238",@"isSelect":@"0"},nil];
    listArr = [HomeMainGoodCellModel mj_objectArrayWithKeyValuesArray:array];
    return listArr.copy;
}

@end
