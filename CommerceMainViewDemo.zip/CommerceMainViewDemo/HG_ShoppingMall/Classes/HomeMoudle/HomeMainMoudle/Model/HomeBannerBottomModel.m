//
//  HomeBannerBottomModel.m
//  HG_ShoppingMall
//
//  Created by Lindashuai on 2019/12/6.
//  Copyright © 2019 Lindashuai. All rights reserved.
//

#import "HomeBannerBottomModel.h"

@implementation HomeBannerBottomModel

+ (NSDictionary *)mj_objectClassInArray {
    return @{@"itemModel":[HomeBannerBottomItemModel class]};
}

+ (NSMutableArray<HomeBannerBottomModel *> *)getHomeBottomViewData {
    NSMutableArray<HomeBannerBottomModel *> *listArr = [NSMutableArray<HomeBannerBottomModel *> array];
    NSArray *array = [NSArray arrayWithObjects:@{@"itemModel":@[@{@"iconImageName":@"Home_icon_wine",@"titleName":@"item 0"},@{@"iconImageName":@"Home_icon_beer",@"titleName":@"item 1"},@{@"iconImageName":@"Home_icon_soda",@"titleName":@"item 2"},@{@"iconImageName":@"Home_icon_mineral-water",@"titleName":@"item 3"}],@"title":@"little banner"},nil];
    listArr = [HomeBannerBottomModel mj_objectArrayWithKeyValuesArray:array];
    return listArr.copy;
}

@end

@implementation HomeBannerBottomItemModel

//@property(nonatomic, strong) NSString *iconImageName;
//@property(nonatomic, strong) NSString *titleName;

@end
