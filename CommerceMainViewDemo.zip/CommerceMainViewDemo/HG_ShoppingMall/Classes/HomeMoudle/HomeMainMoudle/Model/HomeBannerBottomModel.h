//
//  HomeBannerBottomModel.h
//  HG_ShoppingMall
//
//  Created by Lindashuai on 2019/12/6.
//  Copyright © 2019 Lindashuai. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HomeBannerBottomModel : NSObject

@property(nonatomic, strong) NSString *title;
@property(nonatomic, strong) NSArray *itemModel;

+ (NSMutableArray<HomeBannerBottomModel *> *)getHomeBottomViewData;

@end

@interface HomeBannerBottomItemModel : NSObject

@property(nonatomic, strong) NSString *iconImageName;
@property(nonatomic, strong) NSString *titleName;

@end
