//
//  HomeMainGoodCellModel.h
//  HG_ShoppingMall
//
//  Created by Lindashuai on 2019/12/7.
//  Copyright © 2019 Lindashuai. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface HomeMainGoodCellModel : NSObject

@property(nonatomic, strong) NSString *goodImage;//商品图片
@property(nonatomic, strong) NSString *goodType;//0 售罄，1 新品，2 折扣，3 促销
@property(nonatomic, strong) NSString *goodName;//张裕窖藏特选干红葡萄酒
@property(nonatomic, strong) NSString *saleCount;//销量: 12315
@property(nonatomic, strong) NSString *hasCount;//库存: 1546
@property(nonatomic, strong) NSString *goodPay;//￥238
@property(nonatomic, strong) NSString *goodTruePay;//建议零售价: ￥200

@property(nonatomic, assign) NSInteger goodCount;// +1 -1
@property(nonatomic, assign) NSInteger isSelect;//是否选中  0 未选择  1 已选择

+ (NSMutableArray<HomeMainGoodCellModel *> *)getHomeMainGoodArr;

@end

NS_ASSUME_NONNULL_END
