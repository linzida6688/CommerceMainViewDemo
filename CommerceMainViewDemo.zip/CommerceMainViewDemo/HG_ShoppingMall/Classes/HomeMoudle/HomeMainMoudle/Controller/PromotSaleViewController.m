//
//  PromotSaleViewController.m
//  HG_ShoppingMall
//
//  Created by Lindashuai on 2019/12/6.
//  Copyright © 2019 Lindashuai. All rights reserved.
//

#import "PromotSaleViewController.h"
#import "PromotSaleView.h"
#import "HomeMainGoodCellModel.h"

@interface PromotSaleViewController ()

@property(nonatomic, strong) PromotSaleView *promotSaleView;

@end

@implementation PromotSaleViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.promotSaleView = [[PromotSaleView alloc]initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height)];
    [self.view addSubview:self.promotSaleView];
    [self.promotSaleView setPromotSaleViewViewData:[HomeMainGoodCellModel getHomeMainGoodArr]];
}

- (void)setType:(NSString *)type {
    [self.promotSaleView setSubTableViewType:type];
}

- (void)setTableViewConset:(CGPoint)conset {
    [self.promotSaleView setTableViewConset:conset];
}

- (void)setTableViewCanscroll:(BOOL)canScroll {
    [self.promotSaleView setTableViewCanscroll:canScroll];
}

@end
