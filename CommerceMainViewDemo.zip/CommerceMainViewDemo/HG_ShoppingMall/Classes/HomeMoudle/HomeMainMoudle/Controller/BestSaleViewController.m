//
//  BestSaleViewController.m
//  HG_ShoppingMall
//
//  Created by Lindashuai on 2019/12/6.
//  Copyright © 2019 Lindashuai. All rights reserved.
//

#import "BestSaleViewController.h"
#import "BestSaleView.h"
#import "HomeMainGoodCellModel.h"

@interface BestSaleViewController ()

@property(nonatomic, strong) BestSaleView *bestSaleView;

@end

@implementation BestSaleViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.bestSaleView = [[BestSaleView alloc]initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height)];
    [self.view addSubview:self.bestSaleView];
    [self.bestSaleView setBestSaleViewData:[HomeMainGoodCellModel getHomeMainGoodArr]];
}

- (void)setTableViewConset:(CGPoint)conset {
    [self.bestSaleView setTableViewConset:conset];
}

- (void)setTableViewCanscroll:(BOOL)canScroll {
    [self.bestSaleView setTableViewCanscroll:canScroll];
}

- (void)setType:(NSString *)type {
    [self.bestSaleView setSubTableViewType:type];
}

@end
