//
//  NewProductViewController.m
//  HG_ShoppingMall
//
//  Created by Lindashuai on 2019/12/6.
//  Copyright © 2019 Lindashuai. All rights reserved.
//

#import "NewProductViewController.h"
#import "NewProductView.h"
#import "HomeMainGoodCellModel.h"

@interface NewProductViewController ()

@property(nonatomic, strong) NewProductView *productView;

@end

@implementation NewProductViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.productView = [[NewProductView alloc]initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height)];
    [self.view addSubview:self.productView];
    [self.productView setNewProductViewData:[HomeMainGoodCellModel getHomeMainGoodArr]];
}

- (void)setType:(NSString *)type {
    [self.productView setSubTableViewType:type];
}

- (void)setTableViewConset:(CGPoint)conset {
    [self.productView setTableViewConset:conset];
}

- (void)setTableViewCanscroll:(BOOL)canScroll {
    [self.productView setTableViewCanscroll:canScroll];
}

@end
