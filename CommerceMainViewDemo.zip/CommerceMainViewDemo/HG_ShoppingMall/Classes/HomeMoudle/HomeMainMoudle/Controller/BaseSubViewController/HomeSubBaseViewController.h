//
//  HomeSubBaseViewController.h
//  HG_ShoppingMall
//
//  Created by Lindashuai on 2019/12/6.
//  Copyright © 2019 Lindashuai. All rights reserved.
//

#import "BaseViewController.h"

@interface HomeSubBaseViewController : BaseViewController

@property(nonatomic, copy) NSString *type;

- (void)setTableViewConset:(CGPoint)conset;
- (void)setTableViewCanscroll:(BOOL)canScroll;

@end
