//
//  HomeSubBaseViewController.m
//  HG_ShoppingMall
//
//  Created by Lindashuai on 2019/12/6.
//  Copyright © 2019 Lindashuai. All rights reserved.
//

#import "HomeSubBaseViewController.h"

@interface HomeSubBaseViewController ()

@end

@implementation HomeSubBaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setNavigationHidden:YES];
}

- (void)setType:(NSString *)type {
    
}

- (void)setTableViewConset:(CGPoint)conset {
    
}

- (void)setTableViewCanscroll:(BOOL)canScroll {
    
}

@end
