//
//  DiscountSaleViewController.m
//  HG_ShoppingMall
//
//  Created by Lindashuai on 2019/12/6.
//  Copyright © 2019 Lindashuai. All rights reserved.
//

#import "DiscountSaleViewController.h"
#import "DiscountSaleView.h"
#import "HomeMainGoodCellModel.h"

@interface DiscountSaleViewController ()

@property(nonatomic, strong) DiscountSaleView *discountSaleView;

@end

@implementation DiscountSaleViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.discountSaleView = [[DiscountSaleView alloc]initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height)];
    [self.view addSubview:self.discountSaleView];
    [self.discountSaleView setDiscountSaleViewData:[HomeMainGoodCellModel getHomeMainGoodArr]];
}

- (void)setType:(NSString *)type {
    [self.discountSaleView setSubTableViewType:type];
}

- (void)setTableViewConset:(CGPoint)conset {
    [self.discountSaleView setTableViewConset:conset];
}

- (void)setTableViewCanscroll:(BOOL)canScroll {
    [self.discountSaleView setTableViewCanscroll:canScroll];
}

@end
