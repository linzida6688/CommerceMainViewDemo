//
//  HomeViewController.m
//  HG_ShoppingMall
//
//  Created by Lindashuai on 2019/11/25.
//  Copyright © 2019 Lindashuai. All rights reserved.
//

#import "HomeViewController.h"
#import "HomeMainView.h"
#import "HomeBannerBottomModel.h"

#import "HomeSubBaseViewController.h"
#import "BestSaleViewController.h"//畅销产品
#import "NewProductViewController.h"//本月新品
#import "PromotSaleViewController.h"//本月促销
#import "DiscountSaleViewController.h"//临期折扣

//#import "SuspensionButton.h"//悬浮按钮

@interface HomeViewController () <HomeMainViewDelegate>

@property(nonatomic, strong) HomeMainView *homeMainView;
//@property(nonatomic, strong) SuspensionButton *suspensionButton;

@property(nonatomic, strong) NSMutableArray *categoryArray;
@property(nonatomic, strong) NSMutableArray *titleArray;

@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setNavigationHidden:YES];
    self.view.backgroundColor = [UIColor colorWithRed:241/255.0 green:240/255.0 blue:240/255.0 alpha:1];
    [self setHomeMainViewUI];
}

- (void)setHomeMainViewUI {
    [self.view addSubview:self.homeMainView];
    __weak typeof(self) weakSelf = self;
    [self.homeMainView setBlock:^(BOOL canScroll) {
        [weakSelf subTabViewCanScroll:canScroll];
    }];
    [self.homeMainView setBannerBottomItem:[HomeBannerBottomModel getHomeBottomViewData]];
    
    //HomeSubBaseViewController *subViewController = self.categoryArray[0];
    //[subViewController.view addSubview:self.suspensionButton];
}

- (HomeMainView *)homeMainView {
    if(_homeMainView == nil) {
        _homeMainView = [[HomeMainView alloc]initWithFrame:self.view.bounds withVC:self withVCarr:self.categoryArray titleArr:self.titleArray];
        _homeMainView.delegate = self;
    }
    return _homeMainView;
}

//- (SuspensionButton *)suspensionButton {
//    if(_suspensionButton == nil) {
//        _suspensionButton = [SuspensionButton buttonWithType:UIButtonTypeCustom];
//        [_suspensionButton addTarget:self action:@selector(suspensionButtonClick:) forControlEvents:UIControlEventTouchUpInside];
//    }
//    return _suspensionButton;
//}

- (NSMutableArray *)titleArray {
    if (_titleArray == nil) {
        _titleArray = [NSMutableArray arrayWithObjects:@"category1",@"category2",@"category3",@"category4", nil];
    }
    return _titleArray;
}

- (NSMutableArray *)categoryArray {
    if (_categoryArray == nil) {
        _categoryArray = [NSMutableArray array];
        BestSaleViewController *bestSaleViewController = [[BestSaleViewController alloc] init];
        [bestSaleViewController setType:self.titleArray[0]];
        [_categoryArray addObject:bestSaleViewController];
        
        NewProductViewController *newProductViewController = [[NewProductViewController alloc] init];
        [newProductViewController setType:self.titleArray[1]];
        [_categoryArray addObject:newProductViewController];
        
        PromotSaleViewController *promotSaleViewController = [[PromotSaleViewController alloc] init];
        [promotSaleViewController setType:self.titleArray[2]];
        [_categoryArray addObject:promotSaleViewController];
        
        DiscountSaleViewController *discountSaleViewController = [[DiscountSaleViewController alloc] init];
        [discountSaleViewController setType:self.titleArray[3]];
        [_categoryArray addObject:discountSaleViewController];
    }
    return _categoryArray;
}

- (void)subTabViewCanScroll:(BOOL)canScroll {
    for (HomeSubBaseViewController *subViewController in self.categoryArray) {
        [subViewController setTableViewCanscroll:canScroll];
        if (!canScroll) {
            [subViewController setTableViewConset:CGPointZero];
        }
    }
}

#pragma mark - HomeMainViewDelegate

- (void)clickBottomCollectionViewItem:(NSIndexPath *)index {//葡萄酒，啤酒，饮料，矿泉水
    
}

- (void)bannerClickImage:(NSIndexPath *)index {//滚动图片的点击

}

- (void)beginClickSearch:(UITextField *)textField {//开始搜索
    
}

- (void)locationClick {//地理位置的点击

}

- (void)shareClick {//分享的点击
    
}

- (void)segmentIndex:(NSInteger)index {
//    HomeSubBaseViewController *subViewController = self.categoryArray[index];
//    [subViewController.view addSubview:self.suspensionButton];
}

- (void)suspensionButtonClick:(UIButton *)sender { //地推验证按钮
    
}

@end
