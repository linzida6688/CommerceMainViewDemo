//
//  PromotSaleViewController.h
//  HG_ShoppingMall
//
//  Created by Lindashuai on 2019/12/6.
//  Copyright © 2019 Lindashuai. All rights reserved.
//

#import "HomeSubBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface PromotSaleViewController : HomeSubBaseViewController

@end

NS_ASSUME_NONNULL_END
