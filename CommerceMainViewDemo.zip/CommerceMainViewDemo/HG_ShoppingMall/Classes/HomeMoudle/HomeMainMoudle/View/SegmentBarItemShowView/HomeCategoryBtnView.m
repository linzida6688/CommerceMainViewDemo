//
//  HomeCategoryBtnView.m
//  HG_ShoppingMall
//
//  Created by Lindashuai on 2019/12/6.
//  Copyright © 2019 Lindashuai. All rights reserved.
//

#import "HomeCategoryBtnView.h"
#import "HomeCategoryShowView.h"

@interface HomeCategoryBtnView () <HomeCategoryShowDelegate>

@property(nonatomic, strong) UIView *lineView;
@property(nonatomic, strong) UIButton *categoryButton;
@property(nonatomic, strong) UIButton *rankButton;
@property(nonatomic, strong) UIButton *chooseButton;

@property(nonatomic, strong) UIButton *grayView;
@property(nonatomic, strong) HomeCategoryShowView *homeCategoryShowView;

@end

@implementation HomeCategoryBtnView

- (instancetype)initWithFrame:(CGRect)frame {
    if(self = [super initWithFrame:frame]) {
        [self addSubview:self.categoryButton];
        [self addSubview:self.rankButton];
        [self addSubview:self.chooseButton];
        [self addSubview:self.lineView];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    [self makeConstraints];
}

- (void)makeConstraints {
    [self.lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.mas_top);
        make.left.equalTo(self.mas_left);
        make.right.equalTo(self.mas_right);
        make.height.mas_equalTo(LYWidth(1));
    }];
    [self.categoryButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.mas_top);
        make.left.equalTo(self.mas_left);
        make.bottom.equalTo(self.mas_bottom);
    }];
    [self.rankButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.mas_top);
        make.left.equalTo(self.categoryButton.mas_right);
        make.bottom.equalTo(self.mas_bottom);
        make.width.equalTo(self.categoryButton.mas_width);
    }];
    [self.chooseButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.mas_top);
        make.left.equalTo(self.rankButton.mas_right);
        make.bottom.equalTo(self.mas_bottom);
        make.right.equalTo(self.mas_right);
        make.width.equalTo(self.rankButton.mas_width);
    }];
}

- (UIButton *)grayView {
    if(_grayView == nil) {
        _grayView = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
        _grayView.backgroundColor = LY_Color_HexAlpha(#1B1B1B, 0.42);
        _grayView.hidden = YES;
        [_grayView addTarget:self action:@selector(grayViewClick) forControlEvents:UIControlEventTouchUpInside];
    }
    return _grayView;
}

- (HomeCategoryShowView *)homeCategoryShowView {
    if(_homeCategoryShowView == nil) {
        _homeCategoryShowView = [[HomeCategoryShowView alloc]initWithFrame:CGRectMake(0, LYWidth(50), SCREEN_WIDTH, LYWidth(34 * 3))];
        _homeCategoryShowView.hidden = YES;
        _homeCategoryShowView.delegate = self;
        [_homeCategoryShowView homeCategoryShowViewIndex:[NSIndexPath indexPathForRow:0 inSection:0]];
    }
    return _homeCategoryShowView;
}

- (UIView *)lineView {
    if(_lineView == nil) {
        _lineView = [[UIView alloc]init];
        _lineView.backgroundColor = LY_Color_Hex(#F1F0F0);
    }
    return _lineView;
}

- (UIButton *)categoryButton {
    if(_categoryButton == nil) {
        _categoryButton = [[UIButton alloc]init];
        _categoryButton.selected = NO;
        _categoryButton.backgroundColor = [UIColor whiteColor];
        _categoryButton.imageEdgeInsets = UIEdgeInsetsMake(0, LYWidth(60), 0, 0);
        _categoryButton.titleEdgeInsets = UIEdgeInsetsMake(0, 0, 0, LYWidth(55));
        [_categoryButton setTitle:@"choose" forState:UIControlStateNormal];
        [_categoryButton setImage:[UIImage imageNamed:@"Category_icon_btndown"] forState:UIControlStateNormal];
        [_categoryButton setImage:[UIImage imageNamed:@"Category_icon_btnup"] forState:UIControlStateSelected];
        _categoryButton.titleLabel.font = [UIFont systemFontOfSize:LYWidth(14)];
        [_categoryButton setTitleColor:LY_Color_Hex(#333333) forState:UIControlStateNormal];
        [_categoryButton setTitleColor:LY_Color_Hex(#DC4842) forState:UIControlStateSelected];
        [_categoryButton addTarget:self action:@selector(categoryHomeButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _categoryButton;
}

- (UIButton *)rankButton {
    if(_rankButton == nil) {
        _rankButton = [[UIButton alloc]init];
        _rankButton.selected = NO;
        _rankButton.backgroundColor = [UIColor whiteColor];
        _rankButton.imageEdgeInsets = UIEdgeInsetsMake(0, LYWidth(60), 0, 0);
        _rankButton.titleEdgeInsets = UIEdgeInsetsMake(0, 0, 0, LYWidth(55));
        [_rankButton setTitle:@"choose" forState:UIControlStateNormal];
        [_rankButton setImage:[UIImage imageNamed:@"Category_icon_btndown"] forState:UIControlStateNormal];
        [_rankButton setImage:[UIImage imageNamed:@"Category_icon_btnup"] forState:UIControlStateSelected];
        _rankButton.titleLabel.font = [UIFont systemFontOfSize:LYWidth(14)];
        [_rankButton setTitleColor:LY_Color_Hex(#333333) forState:UIControlStateNormal];
        [_rankButton setTitleColor:LY_Color_Hex(#DC4842) forState:UIControlStateSelected];
    }
    return _rankButton;
}

- (UIButton *)chooseButton {
    if(_chooseButton == nil) {
        _chooseButton = [[UIButton alloc]init];
        _chooseButton.selected = NO;
        _chooseButton.backgroundColor = [UIColor whiteColor];
        _chooseButton.imageEdgeInsets = UIEdgeInsetsMake(0, LYWidth(60), 0, 0);
        _chooseButton.titleEdgeInsets = UIEdgeInsetsMake(0, 0, 0, LYWidth(55));
        [_chooseButton setTitle:@"choose" forState:UIControlStateNormal];
        [_chooseButton setImage:[UIImage imageNamed:@"Category_icon_btndown"] forState:UIControlStateNormal];
        [_chooseButton setImage:[UIImage imageNamed:@"Category_icon_btnup"] forState:UIControlStateSelected];
        _chooseButton.titleLabel.font = [UIFont systemFontOfSize:LYWidth(14)];
        [_chooseButton setTitleColor:LY_Color_Hex(#333333) forState:UIControlStateNormal];
        [_chooseButton setTitleColor:LY_Color_Hex(#DC4842) forState:UIControlStateSelected];
    }
    return _chooseButton;
}

- (void)setSubViewController:(UIViewController *)vc {
    [vc.view addSubview:self.grayView];
    [vc.view addSubview:self.homeCategoryShowView];
}

#pragma mark - rankButtonAction chooseButtonAction

- (void)categoryHomeButtonAction:(UIButton *)sender {
    if(sender.selected) {//分类 收起
        self.categoryButton.selected = NO;
        [self grayViewClick];
    } else {//分类 展开
        self.rankButton.selected = NO;
        self.chooseButton.selected = NO;
        self.categoryButton.selected = YES;
        self.grayView.hidden = NO;
        
        self.homeCategoryShowView.hidden = NO;
    }
}

#pragma mark - grayViewClick

- (void)grayViewClick {
    self.grayView.hidden = YES;
    if(self.categoryButton.isSelected) {
        self.categoryButton.selected = NO;
    }
    if(self.rankButton.isSelected) {
        self.rankButton.selected = NO;
    }
    if(self.chooseButton.isSelected) {
        self.chooseButton.selected = NO;
    }
    if(!self.homeCategoryShowView.isHidden) {
        self.homeCategoryShowView.hidden = YES;
    }
}

#pragma mark - HomeCategoryShowDelegate

- (void)clickHomeCategoryShowViewCell:(NSIndexPath *)index model:(NSString *)text {
    
}

@end
