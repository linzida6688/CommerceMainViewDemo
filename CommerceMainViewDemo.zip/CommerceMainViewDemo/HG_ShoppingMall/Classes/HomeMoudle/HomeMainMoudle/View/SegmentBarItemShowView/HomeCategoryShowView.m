//
//  HomeCategoryShowView.m
//  HG_ShoppingMall
//
//  Created by Lindashuai on 2019/12/7.
//  Copyright © 2019 Lindashuai. All rights reserved.
//

#import "HomeCategoryShowView.h"
#import "HomeCategoryShowCell.h"

static NSString *const kHomeCategoryShowCellID = @"kHomeCategoryShowCellID";
@interface HomeCategoryShowView () <UITableViewDelegate,UITableViewDataSource>

@property(nonatomic, strong) UITableView *tableView;
@property(nonatomic, strong) NSMutableArray *dataArr;

@end

@implementation HomeCategoryShowView

- (instancetype)initWithFrame:(CGRect)frame {
    if(self = [super initWithFrame:frame]) {
        [self addSubview:self.tableView];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    [self makeConstraints];
}

- (void)makeConstraints {
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.mas_top);
        make.left.equalTo(self.mas_left);
        make.height.mas_equalTo(LYWidth(34 * 3));
        make.right.equalTo(self.mas_right);
    }];
}

- (NSMutableArray *)dataArr {
    if(_dataArr == nil) {
        _dataArr = [NSMutableArray arrayWithObjects:@"choose cell 0",@"choose cell 1",@"choose cell 2", nil];
    }
    return _dataArr;
}

#pragma mark - tableView

- (UITableView *)tableView {
    if(_tableView == nil) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tableView.backgroundColor = [UIColor clearColor];
        _tableView.scrollEnabled = NO;
        _tableView.delegate = self;
        _tableView.dataSource = self;
    }
    return _tableView;
}

#pragma mark - tableViewDataSource

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return LYWidth(34);
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    HomeCategoryShowCell *cell = [tableView dequeueReusableCellWithIdentifier:kHomeCategoryShowCellID];
    if (cell == nil) {
        cell = [[HomeCategoryShowCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:kHomeCategoryShowCellID];
    }
    [cell setHomeCategoryShowCellText:self.dataArr[indexPath.row]];
    
    return cell;
}

#pragma mark - tableViewDelagte AllListCellDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if(_delegate && [_delegate respondsToSelector:@selector(clickHomeCategoryShowViewCell:model:)]) {
        [_delegate clickHomeCategoryShowViewCell:indexPath model:self.dataArr[indexPath.row]];
    }
}

- (void)homeCategoryShowViewIndex:(NSIndexPath *)index {
    [self.tableView selectRowAtIndexPath:index animated:YES scrollPosition:UITableViewScrollPositionNone];
}

@end
