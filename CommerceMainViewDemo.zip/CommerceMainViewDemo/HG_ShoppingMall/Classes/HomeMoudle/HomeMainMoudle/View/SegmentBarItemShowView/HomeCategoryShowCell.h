//
//  HomeCategoryShowCell.h
//  HG_ShoppingMall
//
//  Created by Lindashuai on 2019/12/7.
//  Copyright © 2019 Lindashuai. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HomeCategoryShowCell : UITableViewCell
- (void)setHomeCategoryShowCellText:(NSString *)text;
@end

NS_ASSUME_NONNULL_END
