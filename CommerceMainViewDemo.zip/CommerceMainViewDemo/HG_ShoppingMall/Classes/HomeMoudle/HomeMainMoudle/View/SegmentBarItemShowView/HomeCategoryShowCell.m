//
//  HomeCategoryShowCell.m
//  HG_ShoppingMall
//
//  Created by Lindashuai on 2019/12/7.
//  Copyright © 2019 Lindashuai. All rights reserved.
//

#import "HomeCategoryShowCell.h"

@interface HomeCategoryShowCell ()

@property(nonatomic, strong) UILabel *title;
@property(nonatomic, strong) UIView *lineView;

@end

@implementation HomeCategoryShowCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if([super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.backgroundColor = [UIColor whiteColor];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        [self addSubview:self.title];
        [self addSubview:self.lineView];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    [self makeConstraints];
}

- (void)makeConstraints {
    [self.title mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.mas_centerY);
        make.left.equalTo(self.mas_left).mas_offset(LYWidth(11.5));
        make.height.mas_equalTo(LYWidth(15));
    }];
    [self.lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.mas_bottom);
        make.left.equalTo(self.mas_left);
        make.right.equalTo(self.mas_right);
        make.height.mas_equalTo(LYWidth(1));
    }];
}

- (UIView *)lineView {
    if(_lineView == nil) {
        _lineView = [[UIView alloc]init];
        _lineView.backgroundColor = LY_Color_Hex(#F1F0F0);
    }
    return _lineView;
}

- (UILabel *)title {
    if(_title == nil) {
        _title = [[UILabel alloc]init];
        _title.text = @"好评最多";
        _title.textAlignment = NSTextAlignmentLeft;
        [_title sizeToFit];
        _title.textColor = LY_Color_Hex(#333333);
        _title.font = [UIFont systemFontOfSize:LYWidth(14)];
    }
    return _title;
}

- (void)setHomeCategoryShowCellText:(NSString *)text {
    self.title.text = text;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    if(selected) {
        self.title.textColor = LY_Color_Hex(#DC4842);
    } else {
        self.title.textColor = LY_Color_Hex(#333333);
    }
}

@end
