//
//  HomeCategoryBtnView.h
//  HG_ShoppingMall
//
//  Created by Lindashuai on 2019/12/6.
//  Copyright © 2019 Lindashuai. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HomeCategoryBtnView : UIView
- (void)setSubViewController:(UIViewController *)vc;
@end

NS_ASSUME_NONNULL_END
