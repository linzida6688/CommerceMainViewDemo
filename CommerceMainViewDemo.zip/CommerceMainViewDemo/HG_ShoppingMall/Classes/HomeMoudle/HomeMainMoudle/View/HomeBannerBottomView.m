//
//  HomeBannerBottomView.m
//  HG_ShoppingMall
//
//  Created by Lindashuai on 2019/12/6.
//  Copyright © 2019 Lindashuai. All rights reserved.
//

#import "HomeBannerBottomView.h"
#import "HomeBottomHeaderView.h"
#import "HomeBannerBottomItem.h"
#import "HomeBannerBottomModel.h"

static NSString *const kHomeBannerBottomItemID = @"kHomeBannerBottomItemID";
@interface HomeBannerBottomView () <UICollectionViewDataSource,UICollectionViewDelegate>

@property(nonatomic, strong) HomeBottomHeaderView *homeBottomHeaderView;
@property(nonatomic, strong) UICollectionView *collectionView;
@property(nonatomic, strong) NSMutableArray<HomeBannerBottomModel *> *arr;

@end

@implementation HomeBannerBottomView

- (instancetype)initWithFrame:(CGRect)frame {
    if(self = [super initWithFrame:frame]) {
        self.backgroundColor = self.superview.backgroundColor;
        [self addSubview:self.homeBottomHeaderView];
        [self addSubview:self.collectionView];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    [self makeConstraints];
}

- (void)makeConstraints {
    [self.homeBottomHeaderView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.mas_top);
        make.left.equalTo(self.mas_left);
        make.right.equalTo(self.mas_right);
        make.height.mas_equalTo(LYWidth(38));
    }];
    [self.collectionView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.homeBottomHeaderView.mas_bottom);
        make.right.equalTo(self.mas_right);
        make.left.equalTo(self.mas_left);
        make.bottom.equalTo(self.mas_bottom).mas_offset(LYWidth(-7.5));
    }];
}

- (HomeBottomHeaderView *)homeBottomHeaderView {
    if(_homeBottomHeaderView == nil) {
        _homeBottomHeaderView = [[HomeBottomHeaderView alloc]init];
    }
    return _homeBottomHeaderView;
}

- (NSMutableArray<HomeBannerBottomModel *> *)arr {
    if(_arr == nil) {
        _arr = [NSMutableArray<HomeBannerBottomModel *> array];
    }
    return _arr;
}

- (void)setHomeBannerBottomModel:(NSMutableArray<HomeBannerBottomModel *> *)arr {
    self.arr = arr.mutableCopy;
    HomeBannerBottomModel *model = [self.arr firstObject];
    [self.homeBottomHeaderView setTitleText:model.title];
    [self.collectionView reloadData];
}

- (UICollectionView *)collectionView {
    if(_collectionView == nil) {
        _collectionView = [[UICollectionView alloc]initWithFrame:CGRectZero collectionViewLayout:[self setupCollectionViewFlowLayout]];
        _collectionView.backgroundColor = [UIColor whiteColor];
        _collectionView.showsHorizontalScrollIndicator = NO;
        _collectionView.showsVerticalScrollIndicator = NO;
        _collectionView.scrollEnabled = YES;
        _collectionView.dataSource = self;
        _collectionView.delegate = self;
        [_collectionView registerClass:[HomeBannerBottomItem class] forCellWithReuseIdentifier:kHomeBannerBottomItemID];
    }
    return _collectionView;
}

#pragma mark - Home collectionView

- (UICollectionViewFlowLayout *)setupCollectionViewFlowLayout {
    CGFloat itemW = SCREEN_WIDTH / 4.0;
    CGFloat itemH = LYWidth(85.5);
    
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc]init];
    layout.itemSize = CGSizeMake(itemW, itemH);
    layout.minimumLineSpacing = LYWidth(0);
    layout.minimumInteritemSpacing = LYWidth(0);
    layout.sectionInset = LYEdgeInsets(0, 0, 0, 0);
    
    return layout;
}

#pragma mark - Mine collectionView dataSource

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    HomeBannerBottomModel *model = [self.arr firstObject];
    return model.itemModel.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    HomeBannerBottomItem *cell = [collectionView dequeueReusableCellWithReuseIdentifier:kHomeBannerBottomItemID forIndexPath:indexPath];
    cell.backgroundColor = [UIColor whiteColor];
    
    HomeBannerBottomModel *model = [self.arr firstObject];
    [cell setHomeBannerBottomItemData:model.itemModel[indexPath.row]];
    
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    if(_delegate && [_delegate respondsToSelector:@selector(clickCollectionViewItem:)]) {
        [_delegate clickCollectionViewItem:indexPath];
    }
}

@end
