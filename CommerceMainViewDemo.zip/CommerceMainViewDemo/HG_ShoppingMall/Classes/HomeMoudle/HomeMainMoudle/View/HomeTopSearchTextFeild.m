//
//  HomeTopSearchTextFeild.m
//  HG_ShoppingMall
//
//  Created by Lindashuai on 2019/12/7.
//  Copyright © 2019 Lindashuai. All rights reserved.
//

#import "HomeTopSearchTextFeild.h"

@implementation HomeTopSearchTextFeild

- (CGRect)leftViewRectForBounds:(CGRect)bounds {
    CGRect iconRect = [super leftViewRectForBounds:bounds];
    iconRect.origin.x += LYWidth(120);
    return iconRect;
}

@end
