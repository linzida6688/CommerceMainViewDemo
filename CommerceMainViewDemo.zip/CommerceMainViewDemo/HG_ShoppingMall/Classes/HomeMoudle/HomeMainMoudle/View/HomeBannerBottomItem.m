//
//  HomeBannerBottomItem.m
//  HG_ShoppingMall
//
//  Created by Lindashuai on 2019/12/6.
//  Copyright © 2019 Lindashuai. All rights reserved.
//

#import "HomeBannerBottomItem.h"
#import "HomeBannerBottomModel.h"

@interface HomeBannerBottomItem ()

@property(nonatomic, strong) UIImageView *iconImageView;
@property(nonatomic, strong) UILabel *iconLabel;

@end

@implementation HomeBannerBottomItem

- (instancetype)initWithFrame:(CGRect)frame {
    if(self = [super initWithFrame:frame]) {
        self.backgroundColor = self.superview.backgroundColor;
        [self addSubview:self.iconImageView];
        [self addSubview:self.iconLabel];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    [self makeConstraints];
}

- (UIImageView *)iconImageView {
    if(_iconImageView == nil) {
        _iconImageView = [[UIImageView alloc] init];
        _iconImageView.layer.cornerRadius = 10;
        _iconImageView.layer.masksToBounds = YES;
        _iconImageView.backgroundColor = [UIColor lightGrayColor];
    }
    return _iconImageView;
}

- (UILabel *)iconLabel {
    if(_iconLabel == nil) {
        _iconLabel = [[UILabel alloc] init];
        _iconLabel.textColor = LY_Color_Hex(#4F4F4F);
        _iconLabel.text = @"item 0";
        _iconLabel.textAlignment = NSTextAlignmentCenter;
        _iconLabel.font = [UIFont systemFontOfSize:LYWidth(13)];
    }
    return _iconLabel;
}

- (void)makeConstraints {
    [self.iconImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.mas_top).mas_offset(LYWidth(12.5));
        make.centerX.equalTo(self.mas_centerX);
        make.size.mas_equalTo(LYSize(41, 42.5));
    }];
    [self.iconLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.iconImageView.mas_bottom).mas_offset(LYWidth(0.5));
        make.right.equalTo(self.mas_right);
        make.left.equalTo(self.mas_left);
        make.height.mas_equalTo(LYWidth(14));
    }];
}

- (void)setHomeBannerBottomItemData:(HomeBannerBottomItemModel *)model {
    self.iconImageView.image = [UIImage imageNamed:model.iconImageName];
    self.iconLabel.text = model.titleName;
}

@end
