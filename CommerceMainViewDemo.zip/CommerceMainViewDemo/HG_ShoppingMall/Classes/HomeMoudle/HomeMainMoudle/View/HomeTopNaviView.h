//
//  HomeTopNaviView.h
//  HG_ShoppingMall
//
//  Created by Lindashuai on 2019/12/7.
//  Copyright © 2019 Lindashuai. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@protocol HomeTopNaviViewDelegate <NSObject>
@optional
- (void)rightBtnBackClick;//返回的点击
- (void)homeTopNaviViewSearchChange:(UITextField *)textField;//搜索的开始
- (void)homeTopNaviViewLocationClick;//地理位置的点击
- (void)homeTopNaviViewShareClick;//分享的点击

@end
@interface HomeTopNaviView : UIView <HomeTopNaviViewDelegate>
@property(nonatomic, weak) id<HomeTopNaviViewDelegate> delegate;
- (void)setHomeTopNaviViewAlpha:(CGFloat)alpha;
@end

NS_ASSUME_NONNULL_END
