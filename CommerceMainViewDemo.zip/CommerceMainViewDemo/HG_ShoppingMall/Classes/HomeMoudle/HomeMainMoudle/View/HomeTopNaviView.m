//
//  HomeTopNaviView.m
//  HG_ShoppingMall
//
//  Created by Lindashuai on 2019/12/7.
//  Copyright © 2019 Lindashuai. All rights reserved.
//

#import "HomeTopNaviView.h"
#import "HomeTopSearchTextFeild.h"

@interface HomeTopNaviView ()

@property(nonatomic, strong) UIImageView *locationImage;
@property(nonatomic, strong) UILabel *locationLabel;
@property(nonatomic, strong) UIImageView *rightImage;
@property(nonatomic, strong) UIButton *locationAction;

@property(nonatomic, strong) UIImageView *shareImage;
@property(nonatomic, strong) HomeTopSearchTextFeild *searchField;
@property(nonatomic, strong) UIImageView *searchImage;
@property(nonatomic, strong) UIView *clearView;

@property(nonatomic, strong) UIView *whiteView;
@property(nonatomic, strong) UIImageView *whiteSearchImage;
@property(nonatomic, strong) UITextField *textField;
@property(nonatomic, strong) UIButton *rightBtn;

@end

@implementation HomeTopNaviView

- (instancetype)initWithFrame:(CGRect)frame {
    if(self = [super initWithFrame:frame]) {
        [self addSubview:self.clearView];
        [self.clearView addSubview:self.locationImage];
        [self.clearView addSubview:self.locationLabel];
        [self.clearView addSubview:self.rightImage];
        [self.clearView addSubview:self.shareImage];
        [self.clearView addSubview:self.locationAction];
        [self.clearView addSubview:self.searchImage];
        [self.clearView addSubview:self.searchField];
        
        [self addSubview:self.whiteView];
        [self.whiteView addSubview:self.textField];
        [self.whiteView addSubview:self.rightBtn];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    [self makeConstraints];
}

- (UIView *)clearView {
    if(_clearView == nil) {
        _clearView = [[UIView alloc]init];
    }
    return _clearView;
}

- (UIImageView *)locationImage {
    if(_locationImage == nil) {
        _locationImage = [[UIImageView alloc]init];
        _locationImage.image = [UIImage imageNamed:@"Home_icon_location"];
    }
    return _locationImage;
}

- (UILabel *)locationLabel {
    if(_locationLabel == nil) {
        _locationLabel = [[UILabel alloc]init];
        _locationLabel.text = @"address  >";
        _locationLabel.textColor = [UIColor whiteColor];
        _locationLabel.textAlignment = NSTextAlignmentLeft;
        _locationLabel.font = [UIFont systemFontOfSize:LYWidth(15)];
    }
    return _locationLabel;
}

- (UIImageView *)rightImage {
    if(_rightImage == nil) {
        _rightImage = [[UIImageView alloc]init];
        _rightImage.image = [UIImage imageNamed:@"Home_icon_right"];
    }
    return _rightImage;
}

- (UIImageView *)shareImage {
    if(_shareImage == nil) {
        _shareImage = [[UIImageView alloc]init];
        _shareImage.image = [UIImage imageNamed:@"Home_icon_share"];
        _shareImage.userInteractionEnabled = YES;
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(shareAction:)];
        [_shareImage addGestureRecognizer:tap];
    }
    return _shareImage;
}

- (UIButton *)locationAction {
    if(_locationAction == nil) {
        _locationAction = [[UIButton alloc]init];
        _locationAction.backgroundColor = [UIColor clearColor];
        [_locationAction addTarget:self action:@selector(locationAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _locationAction;
}

- (UIImageView *)searchImage {
    if(_searchImage == nil) {
        _searchImage = [[UIImageView alloc]initWithFrame:LYFrame(0, 0, 26.5, 13.5)];
        _searchImage.clipsToBounds = YES;
        _searchImage.contentMode = UIViewContentModeScaleAspectFit;
        _searchImage.image = [UIImage imageNamed:@"Home_icon_search"];
    }
    return _searchImage;
}

- (HomeTopSearchTextFeild *)searchField {
    if(_searchField == nil) {
        _searchField = [[HomeTopSearchTextFeild alloc]init];
        _searchField.placeholder = @"search";
        _searchField.layer.masksToBounds = YES;
        _searchField.layer.cornerRadius = LYWidth(4.5);
        _searchField.backgroundColor = [UIColor whiteColor];
        _searchField.leftView = self.searchImage;
        _searchField.leftViewMode = UITextFieldViewModeAlways;
        [_searchField addTarget:self action:@selector(searchTextFieldChange:) forControlEvents:UIControlEventEditingDidBegin];
    }
    return _searchField;
}

- (UIImageView *)whiteSearchImage {
    if(_whiteSearchImage == nil) {
        _whiteSearchImage = [[UIImageView alloc]initWithFrame:LYFrame(0, 0, 26.5, 13.5)];
        _whiteSearchImage.clipsToBounds = YES;
        _whiteSearchImage.contentMode = UIViewContentModeScaleAspectFit;
        _whiteSearchImage.image = [UIImage imageNamed:@"Home_icon_search"];
    }
    return _whiteSearchImage;
}

- (UIView *)whiteView {
    if(_whiteView == nil) {
        _whiteView = [[UIView alloc]init];
        _whiteView.backgroundColor = [UIColor whiteColor];
        _whiteView.alpha = 0;
    }
    return _whiteView;
}

- (UITextField *)textField {
    if(_textField == nil) {
        _textField = [[UITextField alloc]init];
        _textField.placeholder = @"search";
        _textField.layer.masksToBounds = YES;
        _textField.layer.cornerRadius = LYWidth(4.5);
        _textField.backgroundColor = LY_Color_Hex(#E2E2E2);
        _textField.leftView = self.whiteSearchImage;
        _textField.leftViewMode = UITextFieldViewModeAlways;
        [_textField addTarget:self action:@selector(searchTextFieldChange:) forControlEvents:UIControlEventEditingDidBegin];
    }
    return _textField;
}

- (UIButton *)rightBtn {
    if(_rightBtn == nil) {
        _rightBtn = [[UIButton alloc]init];
        [_rightBtn setImage:[UIImage imageNamed:@"icon_black_back"] forState:UIControlStateNormal];
        [_rightBtn addTarget:self action:@selector(rightBtnBack:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _rightBtn;
}

- (void)makeConstraints {
    self.clearView.frame = self.bounds;
    [self.searchField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.mas_left).mas_offset(LYWidth(10.5));
        make.bottom.equalTo(self.mas_bottom);
        make.right.equalTo(self.mas_right).mas_offset(LYWidth(-9.5));
        make.height.mas_equalTo(LYWidth(30));
    }];
    [self.locationImage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.searchField.mas_left);
        make.bottom.equalTo(self.searchField.mas_top).mas_offset(LYWidth(-16));
        make.size.mas_equalTo(LYSize(18, 20));
    }];
    [self.locationLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.locationImage.mas_right).mas_offset(LYWidth(15.5));
        make.centerY.equalTo(self.locationImage.mas_centerY);
        make.height.mas_equalTo(LYWidth(16));
    }];
    [self.rightImage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.locationLabel.mas_right).mas_offset(LYWidth(9));
        make.centerY.equalTo(self.locationImage.mas_centerY);
        make.size.mas_equalTo(LYSize(6.5, 12.5));
    }];
    [self.locationAction mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.locationImage.mas_top);
        make.left.equalTo(self.locationImage.mas_left);
        make.bottom.equalTo(self.locationImage.mas_bottom);
        make.right.equalTo(self.rightImage.mas_right);
    }];
    [self.shareImage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.searchField.mas_right);
        make.centerY.equalTo(self.locationImage.mas_centerY);
        make.size.mas_equalTo(LYSize(18.5, 18));
    }];
    
    [self.whiteView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.mas_top);
        make.left.equalTo(self.mas_left);
        make.right.equalTo(self.mas_right);
        make.height.mas_equalTo(LYWidth(98));
    }];
    [self.textField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.whiteView.mas_left).mas_offset(LYWidth(44));
        make.bottom.equalTo(self.whiteView.mas_bottom).mas_offset(LYWidth(-10));
        make.right.equalTo(self.whiteView.mas_right).mas_offset(LYWidth(-31.5));
        make.height.mas_equalTo(LYWidth(30));
    }];
    [self.rightBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.whiteView.mas_left);
        make.right.equalTo(self.textField.mas_left);
        make.centerY.equalTo(self.textField.mas_centerY);
        make.height.mas_equalTo(LYWidth(31.5));
    }];
}

#pragma mark - setalpha

- (void)setHomeTopNaviViewAlpha:(CGFloat)alpha {
    CGFloat offsetY = LYWidth(98) - TOP_AND_SYSTEM_HEIGHT;
    self.hidden = [self naviGationViewHidden:alpha];
    if(alpha > 0) {
        self.transform = CGAffineTransformMakeTranslation(0, - offsetY * alpha);
        //self.clearView.hidden = YES;
        self.clearView.alpha = (1 - alpha);
        
        self.whiteView.hidden = NO;
        self.whiteView.alpha = alpha;
    } else {
        self.whiteView.hidden = YES;
        //self.clearView.hidden = NO;
    }
}

- (BOOL)naviGationViewHidden:(CGFloat)alpha {
    if(IS_IPHONE_5) {
        if(alpha < -0.0006815) {//-0.0006815 iphone5s的微小偏移量
            return YES;
        } else {
            return NO;
        }
    } else {
        if(alpha < 0) {
            return YES;
        } else {
             return NO;
        }
    }
}

#pragma mark - locationAction

- (void)locationAction:(UIButton *)sender {
    if(_delegate && [_delegate respondsToSelector:@selector(homeTopNaviViewLocationClick)]) {
        [_delegate homeTopNaviViewLocationClick];
    }
}

#pragma mark - shareAction

- (void)shareAction:(UITapGestureRecognizer *)tap {
    if(_delegate && [_delegate respondsToSelector:@selector(homeTopNaviViewShareClick)]) {
        [_delegate homeTopNaviViewShareClick];
    }
}

#pragma mark - searchTextFieldChange

- (void)searchTextFieldChange:(UITextField *)sender {
    if(_delegate && [_delegate respondsToSelector:@selector(homeTopNaviViewSearchChange:)]) {
        [_delegate homeTopNaviViewSearchChange:sender];
    }
}

#pragma mark - rightBtnBack

- (void)rightBtnBack:(UIButton *)sender {
    if(_delegate && [_delegate respondsToSelector:@selector(rightBtnBackClick)]) {
        [_delegate rightBtnBackClick];
    }
}

@end
