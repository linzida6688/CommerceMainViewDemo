//
//  HomeHeaderRefresh.m
//  HG_ShoppingMall
//
//  Created by Lindashuai on 2020/11/23.
//  Copyright © 2020 Lindashuai. All rights reserved.
//

#import "HomeHeaderRefresh.h"

@implementation HomeHeaderRefresh

- (instancetype)init {
    if (self = [super init]) {
        self.lastUpdatedTimeLabel.hidden = YES;
        self.stateLabel.hidden = YES;
    }
    return self;
}

@end
