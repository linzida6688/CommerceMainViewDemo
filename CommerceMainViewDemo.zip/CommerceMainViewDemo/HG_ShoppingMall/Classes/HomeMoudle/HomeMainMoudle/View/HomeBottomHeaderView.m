//
//  HomeBottomHeaderView.m
//  HG_ShoppingMall
//
//  Created by Lindashuai on 2019/12/6.
//  Copyright © 2019 Lindashuai. All rights reserved.
//

#import "HomeBottomHeaderView.h"

@interface HomeBottomHeaderView ()

@property(nonatomic, strong) UIView *whiteBgView;
@property(nonatomic, strong) UILabel *titleLabel;

@end

@implementation HomeBottomHeaderView

- (instancetype)initWithFrame:(CGRect)frame {
    if(self = [super initWithFrame:frame]) {
        self.backgroundColor = self.superview.backgroundColor;
        [self addSubview:self.whiteBgView];
        [self addSubview:self.titleLabel];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    [self makeConstraints];
}

- (void)makeConstraints {
    [self.whiteBgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.mas_top).mas_offset(LYWidth(4));
        make.left.equalTo(self.mas_left);
        make.right.equalTo(self.mas_right);
        make.bottom.equalTo(self.mas_bottom).mas_offset(LYWidth(-4));
    }];
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.mas_centerY);
        make.left.equalTo(self.mas_left).mas_offset(LYWidth(8.5));
        make.height.mas_equalTo(15);
    }];
}

- (UIView *)whiteBgView {
    if(_whiteBgView == nil) {
        _whiteBgView = [[UIView alloc]init];
        _whiteBgView.backgroundColor = [UIColor whiteColor];
    }
    return _whiteBgView;
}

- (UILabel *)titleLabel {
    if(_titleLabel == nil) {
        _titleLabel = [[UILabel alloc]init];
        _titleLabel.text = @"little banner";
        _titleLabel.textAlignment = NSTextAlignmentLeft;
        [_titleLabel sizeToFit];
        _titleLabel.textColor = LY_Color_Hex(#4F4F4F);
        _titleLabel.font = [UIFont systemFontOfSize:LYWidth(14)];
    }
    return _titleLabel;
}

- (void)setTitleText:(NSString *)string {
    self.titleLabel.text = string;
}

@end
