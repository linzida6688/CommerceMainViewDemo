//
//  HomeMainView.m
//  HG_ShoppingMall
//
//  Created by Lindashuai on 2019/12/6.
//  Copyright © 2019 Lindashuai. All rights reserved.
//

#import "HomeMainView.h"
#import "HomeTopNaviView.h"
#import "BannerView.h"
#import "SegmentView.h"
#import "SegMainScrollView.h"
#import "BaseTableView.h"
#import "HomeHeaderRefresh.h"

#import "HomeBannerBottomView.h"
#import "HomeBannerBottomModel.h"

#define BANNER_HEIGHT LYWidth(300)
#define BANNERBOTTOM LYWidth(131)

static NSString *const kHomeMainCell = @"kHomeMainCell";
@interface HomeMainView () <UITableViewDelegate,UITableViewDataSource,HomeBannerBottomViewDelegate,HomeTopNaviViewDelegate>

@property(nonatomic, strong) UIViewController *viewController;

@property(nonatomic, strong) HomeTopNaviView *homeTopNaviView;
@property(nonatomic, strong) HomeBannerBottomView *homeBannerBottomView;
@property(nonatomic, strong) BaseTableView *tableView;
@property(nonatomic, strong) SegmentView *segView;
@property(nonatomic, assign) BOOL canScroll;

@property(nonatomic, strong) NSMutableArray *segArray;
@property(nonatomic, strong) NSMutableArray *titleArray;

@end

@implementation HomeMainView

- (instancetype)initWithFrame:(CGRect)frame withVC:(UIViewController *)vc withVCarr:(NSMutableArray *)vcarr titleArr:(NSMutableArray *)titleArr {
    if(self = [super initWithFrame:frame]) {
        self.viewController = vc;
        self.segArray = vcarr;
        self.titleArray = titleArr;
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(notification) name:@"tabNoti" object:nil];
        self.canScroll = YES;
        [self setSubViews];
        
//        UISwipeGestureRecognizer *swipeGestureRecognizer = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swipeGestureRecognizer:)];
//        [self addGestureRecognizer:swipeGestureRecognizer];
    }
    return self;
}

- (void)notification {
    self.canScroll = YES;
    if(self.block) {
        self.block(NO);
    }
}
- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)setSubViews {
    [self addSubview:self.tableView];
    
    //banner图
    NSArray *images = @[@"top_banner",@"top_banner",@"top_banner"];
    __weak typeof(self) weakSelf = self;
    [BannerView showBannerWithFrame:CGRectMake(0, - BANNER_HEIGHT - BANNERBOTTOM, SCREEN_WIDTH, BANNER_HEIGHT) images:images superView:self.tableView tapBlock:^(NSInteger index) {
        //NSLog(@"点击了第%ld张",index);
        [weakSelf performSelector:@selector(bannerImageClick:) withObject:[NSIndexPath indexPathWithIndex:index]];
    }];
    
    [self.tableView addSubview:self.homeBannerBottomView];
    [self addSubview:self.homeTopNaviView];
}

- (HomeTopNaviView *)homeTopNaviView {
    if(_homeTopNaviView == nil) {
        _homeTopNaviView = [[HomeTopNaviView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, LYWidth(98))];//LYWidth(98)UI长度
        _homeTopNaviView.delegate = self;
    }
    return _homeTopNaviView;
}

- (HomeBannerBottomView *)homeBannerBottomView {
    if(_homeBannerBottomView == nil) {
        _homeBannerBottomView = [[HomeBannerBottomView alloc]initWithFrame:CGRectMake(0, - BANNERBOTTOM, SCREEN_WIDTH, BANNERBOTTOM)];
        _homeBannerBottomView.delegate = self;
    }
    return _homeBannerBottomView;
}

- (SegmentView *)segView {//分栏控制器
    if(_segView == nil) {
        CGRect frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);//40
        _segView = [[SegmentView alloc]initWithFrame:frame items:self.titleArray pageView:self.segArray parentVC:self.viewController];
        _segView.firstSelectPage = 0;
        __weak typeof(self) weakSelf = self;
        _segView.segmentBlock = ^(NSInteger selectIndex) {
            //NSLog(@"%@",self.titleArray[selectIndex]);
            if(weakSelf.delegate && [weakSelf.delegate respondsToSelector:@selector(segmentIndex:)]) {
                [weakSelf.delegate segmentIndex:selectIndex];
            }
        };
    }
    return _segView;
}

#pragma mark - TableViewController

- (BaseTableView *)tableView {
    if (_tableView == nil) {
        _tableView = [[BaseTableView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT) style:UITableViewStylePlain];
        if (@available(iOS 11.0,*)) {
            _tableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
        } else {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
            self.viewController.automaticallyAdjustsScrollViewInsets = NO;
#pragma clang diagnostic pop
        }
        _tableView.backgroundColor = self.superview.backgroundColor;
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.estimatedRowHeight = 0;
        _tableView.contentInset = UIEdgeInsetsMake(BANNER_HEIGHT + BANNERBOTTOM, 0, 0, 0);
        __weak typeof(self) weakSelf = self;
        _tableView.mj_header = [HomeHeaderRefresh headerWithRefreshingBlock:^{
            [weakSelf endRefresh];
        }];
        [_tableView.mj_header beginRefreshing];
    }
    return _tableView;
}

- (void)endRefresh {
    [self.tableView.mj_header endRefreshing];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return SCREEN_HEIGHT;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:kHomeMainCell];
    if (cell == nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:kHomeMainCell];
    }
    [cell.contentView addSubview:self.segView];
    return cell;
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    CGFloat naviH = TOP_AND_SYSTEM_HEIGHT;
    if (scrollView.contentOffset.y > -naviH) {
        scrollView.contentOffset = CGPointMake(0, - naviH);
        if (self.canScroll) {
            self.canScroll = NO;
            if(self.block) {
                self.block(YES);
            }
        }
    } else {
        if (!self.canScroll) {
            scrollView.contentOffset = CGPointMake(0, - naviH);
        }
    }
    CGFloat alpha = (scrollView.contentOffset.y + BANNER_HEIGHT + BANNERBOTTOM) / (BANNERBOTTOM + BANNER_HEIGHT - naviH);
    [self.homeTopNaviView setHomeTopNaviViewAlpha:alpha];//topNavi的变化
}

#pragma mark - HomeTopNaviViewDelegate

- (void)rightBtnBackClick {
    [self.tableView setContentOffset:CGPointMake(0, - BANNER_HEIGHT - BANNERBOTTOM) animated:YES];
    self.canScroll = YES;
    if(self.block) {
        self.block(NO);
    }
    //self.segView.scrollview.scrollEnabled = YES;
}

#pragma mark - swipeGestureRecognizer

//- (void)swipeGestureRecognizer:(UISwipeGestureRecognizer *)tap {
//    if(tap.direction == UISwipeGestureRecognizerDirectionRight && !self.canScroll && self.segView.index == 0) {
//        self.segView.scrollview.scrollEnabled = NO;
//        [self rightBtnBackClick];
//    } else {
//        return;
//    }
//}

#pragma mark - setsetBannerBottomItemData

- (void)setBannerBottomItem:(NSMutableArray<HomeBannerBottomModel *> *)arr {
    [self.homeBannerBottomView setHomeBannerBottomModel:arr];
}

#pragma mark - HomeBannerBottomViewDelegate

- (void)clickCollectionViewItem:(NSIndexPath *)index {
    if(_delegate && [_delegate respondsToSelector:@selector(clickBottomCollectionViewItem:)]) {
        [_delegate clickBottomCollectionViewItem:index];
    }
}

- (void)bannerImageClick:(NSIndexPath *)index {
    if(_delegate && [_delegate respondsToSelector:@selector(bannerClickImage:)]) {
        [_delegate bannerClickImage:index];
    }
}

- (void)homeTopNaviViewSearchChange:(UITextField *)textField {
    if(_delegate && [_delegate respondsToSelector:@selector(beginClickSearch:)]) {
        [_delegate beginClickSearch:textField];
    }
}

- (void)homeTopNaviViewLocationClick {
    if(_delegate && [_delegate respondsToSelector:@selector(locationClick)]) {
        [_delegate locationClick];
    }
}

- (void)homeTopNaviViewShareClick {
    if(_delegate && [_delegate respondsToSelector:@selector(shareClick)]) {
        [_delegate shareClick];
    }
}

@end
