//
//  BannerProxy.h
//  HG_ShoppingMall
//
//  Created by Lindashuai on 2019/12/8.
//  Copyright © 2019 Lindashuai. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BannerProxy : NSProxy

+ (instancetype)proxyWithTarget:(id)target;
@property (weak, nonatomic) id target;

@end
