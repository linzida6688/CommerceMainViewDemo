//
//  BannerProxy.m
//  HG_ShoppingMall
//
//  Created by Lindashuai on 2019/12/8.
//  Copyright © 2019 Lindashuai. All rights reserved.
//

#import "BannerProxy.h"

@implementation BannerProxy

+ (instancetype)proxyWithTarget:(id)target {
    BannerProxy *proxy = [BannerProxy alloc];
    proxy.target = target;
    return proxy;
}

- (NSMethodSignature *)methodSignatureForSelector:(SEL)selector {
    return [self.target methodSignatureForSelector:selector];
}

- (void)forwardInvocation:(NSInvocation *)invocation {
    [invocation invokeWithTarget:self.target];
}

@end
