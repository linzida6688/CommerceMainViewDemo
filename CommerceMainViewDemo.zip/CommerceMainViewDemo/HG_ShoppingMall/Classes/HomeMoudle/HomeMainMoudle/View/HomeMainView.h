//
//  HomeMainView.h
//  HG_ShoppingMall
//
//  Created by Lindashuai on 2019/12/6.
//  Copyright © 2019 Lindashuai. All rights reserved.
//

#import <UIKit/UIKit.h>

@class HomeBannerBottomModel;
@protocol HomeMainViewDelegate <NSObject>
@optional
- (void)clickBottomCollectionViewItem:(NSIndexPath *)index;
- (void)bannerClickImage:(NSIndexPath *)index;
- (void)beginClickSearch:(UITextField *)textField;
- (void)locationClick;
- (void)shareClick;
- (void)segmentIndex:(NSInteger)index;

@end
@interface HomeMainView : UIView <HomeMainViewDelegate>
@property(nonatomic, weak) id<HomeMainViewDelegate> delegate;

@property(nonatomic, copy) void(^block)(BOOL canScroll);
- (instancetype)initWithFrame:(CGRect)frame withVC:(UIViewController *)vc withVCarr:(NSMutableArray *)vcarr titleArr:(NSMutableArray *)titleArr;

- (void)setBannerBottomItem:(NSMutableArray<HomeBannerBottomModel *> *)arr;

@end
