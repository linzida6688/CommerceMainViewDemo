//
//  BaseTableView.m
//  HG_ShoppingMall
//
//  Created by Lindashuai on 2019/12/6.
//  Copyright © 2019 Lindashuai. All rights reserved.
//

#import "BaseTableView.h"

@interface BaseTableView () <UIGestureRecognizerDelegate>

@end

@implementation BaseTableView

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {//YES 识别两个手势
    return YES;
}

@end
