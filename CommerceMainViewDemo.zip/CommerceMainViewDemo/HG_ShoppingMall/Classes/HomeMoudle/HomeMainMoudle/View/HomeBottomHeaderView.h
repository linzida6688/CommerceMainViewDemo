//
//  HomeBottomHeaderView.h
//  HG_ShoppingMall
//
//  Created by Lindashuai on 2019/12/6.
//  Copyright © 2019 Lindashuai. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HomeBottomHeaderView : UIView
- (void)setTitleText:(NSString *)string;
@end

NS_ASSUME_NONNULL_END
