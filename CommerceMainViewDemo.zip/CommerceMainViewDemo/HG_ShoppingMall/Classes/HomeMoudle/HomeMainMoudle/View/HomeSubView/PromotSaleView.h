//
//  PromotSaleView.h
//  HG_ShoppingMall
//
//  Created by Lindashuai on 2019/12/6.
//  Copyright © 2019 Lindashuai. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@class HomeMainGoodCellModel;
@interface PromotSaleView : UIView

- (void)setTableViewConset:(CGPoint)conset;
- (void)setTableViewCanscroll:(BOOL)canScroll;

- (void)setSubTableViewType:(NSString *)type;
- (void)setPromotSaleViewViewData:(NSMutableArray<HomeMainGoodCellModel *> *)arr;

@end

NS_ASSUME_NONNULL_END
