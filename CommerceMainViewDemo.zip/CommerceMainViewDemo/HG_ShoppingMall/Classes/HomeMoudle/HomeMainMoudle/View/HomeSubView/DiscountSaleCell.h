//
//  DiscountSaleCell.h
//  HG_ShoppingMall
//
//  Created by Lindashuai on 2019/12/7.
//  Copyright © 2019 Lindashuai. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class HomeMainGoodCellModel;
@interface DiscountSaleCell : UITableViewCell
- (void)setDiscountSaleCellModel:(HomeMainGoodCellModel *)cellModel;
@end

NS_ASSUME_NONNULL_END
