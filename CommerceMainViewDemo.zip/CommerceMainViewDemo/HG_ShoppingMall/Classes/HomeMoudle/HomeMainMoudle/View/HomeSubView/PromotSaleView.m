//
//  PromotSaleView.m
//  HG_ShoppingMall
//
//  Created by Lindashuai on 2019/12/6.
//  Copyright © 2019 Lindashuai. All rights reserved.
//

#import "PromotSaleView.h"
#import "PromotSaleCell.h"
#import "HomeMainGoodCellModel.h"

#define ITEM_CATGORY_HEIGHT LYWidth(90)
#define Tabbar_HEIGHT (IS_IPHONE_X ? LYWidth(35) : 0)

static NSString *const kPromotSaleViewCell = @"kPromotSaleViewCell";
@interface PromotSaleView () <UITableViewDelegate,UITableViewDataSource>

@property(nonatomic, strong) UITableView *tableView;
@property(nonatomic, strong) NSMutableArray<HomeMainGoodCellModel *> *listArr;
@property(nonatomic, assign) BOOL canScroll;
@property(nonatomic, strong) NSString *type;

@end

@implementation PromotSaleView

- (instancetype)initWithFrame:(CGRect)frame {
    if(self = [super initWithFrame:frame]) {
        [self addSubview:self.tableView];
    }
    return self;
}

- (NSMutableArray<HomeMainGoodCellModel *> *)listArr {
    if(_listArr == nil) {
        _listArr = [NSMutableArray<HomeMainGoodCellModel *> array];
    }
    return _listArr;
}

#pragma mark - tablViewLazy

- (UITableView *)tableView {
    if (_tableView == nil) {
        CGFloat naviH = TOP_AND_SYSTEM_HEIGHT;
        _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, LYWidth(50), SCREEN_WIDTH, SCREEN_HEIGHT - ITEM_CATGORY_HEIGHT - naviH - Tabbar_HEIGHT - LYWidth(50)) style:UITableViewStylePlain];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.rowHeight = LYWidth(103);
    }
    return _tableView;
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.listArr.count;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    PromotSaleCell *cell = [tableView dequeueReusableCellWithIdentifier:kPromotSaleViewCell];
    if (cell == nil) {
        cell = [[PromotSaleCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:kPromotSaleViewCell];
    }
    HomeMainGoodCellModel *cellModel = self.listArr[indexPath.row];
    [cell setPromotSaleCellModel:cellModel];
    return cell;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    if (!self.canScroll) {
        scrollView.contentOffset = CGPointZero;
    }
    if (scrollView.contentOffset.y <= 0) {
        self.canScroll = NO;
        scrollView.contentOffset = CGPointZero;
        [[NSNotificationCenter defaultCenter] postNotificationName:@"tabNoti" object:nil];
    }
}

- (void)setTableViewConset:(CGPoint)conset {
    self.tableView.contentOffset = conset;
}

- (void)setTableViewCanscroll:(BOOL)canScroll {
    self.canScroll = canScroll;
}

- (void)setSubTableViewType:(NSString *)type {
    self.type = type;
    [self.tableView reloadData];
}

#pragma mark - setData

- (void)setPromotSaleViewViewData:(NSMutableArray<HomeMainGoodCellModel *> *)arr {
    self.listArr = arr.mutableCopy;
    [self.tableView reloadData];
}

@end
