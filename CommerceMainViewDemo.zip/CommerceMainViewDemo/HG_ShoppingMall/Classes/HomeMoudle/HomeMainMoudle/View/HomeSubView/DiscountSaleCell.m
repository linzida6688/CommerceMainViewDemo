//
//  DiscountSaleCell.m
//  HG_ShoppingMall
//
//  Created by Lindashuai on 2019/12/7.
//  Copyright © 2019 Lindashuai. All rights reserved.
//

#import "DiscountSaleCell.h"
#import "HomeMainGoodCellModel.h"

@interface DiscountSaleCell ()

@property(nonatomic, strong) UIImageView *goodImage;//商品图片
@property(nonatomic, strong) UILabel *goodNameLabel;//张裕窖藏特选干红葡萄酒
@property(nonatomic, strong) UIView *lineView;

@property(nonatomic, strong) HomeMainGoodCellModel *cellModel;

@end

@implementation DiscountSaleCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if([super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.backgroundColor = [UIColor lightGrayColor];
        [self.contentView addSubview:self.goodImage];
        [self.contentView addSubview:self.goodNameLabel];
        [self.contentView addSubview:self.lineView];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    [self makeConstraints];
}

- (UIImageView *)goodImage {
    if(_goodImage == nil) {
        _goodImage = [[UIImageView alloc]init];
        _goodImage.image = [UIImage imageNamed:@"icon_winebottle"];
    }
    return _goodImage;
}

- (UILabel *)goodNameLabel {
    if(_goodNameLabel == nil) {
        _goodNameLabel = [[UILabel alloc]init];
        _goodNameLabel.text = @"张裕窖藏特选干红葡萄酒";
        _goodNameLabel.textAlignment = NSTextAlignmentLeft;
        [_goodNameLabel sizeToFit];
        _goodNameLabel.textColor = LY_Color_Hex(#333333);
        _goodNameLabel.font = [UIFont systemFontOfSize:LYWidth(14)];
    }
    return _goodNameLabel;
}

- (void)makeConstraints {
    [self.goodImage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.mas_top).mas_offset(LYWidth(15));
        make.left.equalTo(self.mas_left).mas_offset(LYWidth(3));
        make.size.mas_equalTo(LYSize(98, 68.5));
    }];
    [self.goodNameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.goodImage.mas_top).mas_offset(LYWidth(1));
        make.left.equalTo(self.goodImage.mas_right).mas_offset(LYWidth(9.5));
        make.height.mas_equalTo(LYWidth(15));
    }];
    [self.lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.mas_leading);
        make.trailing.equalTo(self.mas_trailing);
        make.bottom.equalTo(self.mas_bottom);
        make.height.mas_equalTo(LYWidth(0.5));
    }];
}

- (UIView *)lineView {
    if(_lineView == nil) {
        _lineView = [[UIView alloc]init];
        _lineView.backgroundColor = [UIColor grayColor];
    }
    return _lineView;
}

- (void)setDiscountSaleCellModel:(HomeMainGoodCellModel *)cellModel {
    self.cellModel = cellModel;
    self.goodImage.image = [UIImage imageNamed:cellModel.goodImage];
    self.goodNameLabel.text = cellModel.goodName;
}

@end
