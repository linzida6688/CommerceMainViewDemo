//
//  SegmentView.m
//  InstrumentPro
//
//  Created by 浅佳科技 on 2018/12/28.
//  Copyright © 2018年 KuaiZhunCheFu. All rights reserved.
//

#import "SegmentView.h"
#import "HomeCategoryBtnView.h"
#import "SegMainScrollView.h"
#import "SegmentBarItem.h"
#import "UIView+Adjust.h"

#define ITEMHEIGHT LYWidth(40)
#define CategoryHEIGHT LYWidth(50)

@interface SegmentView () <UIScrollViewDelegate>

@property(nonatomic, strong) HomeCategoryBtnView *homeCategoryBtnView;
@property(nonatomic, strong) SegmentBarItem *itemView;
@property(nonatomic, assign) CGFloat startOffsetx;
@property(nonatomic, strong) NSMutableArray *vcArr;

@end

@implementation SegmentView

- (instancetype)initWithFrame:(CGRect)frame items:(NSArray *)itemArray pageView:(NSArray *)pageViewArray parentVC:(UIViewController *)parentVC {
    if (self = [super initWithFrame:frame]) {
        [self setSubViewsWithItemArray:itemArray pageView:pageViewArray parentVC:parentVC];
        self.vcArr = pageViewArray.mutableCopy;
    }
    return self;
}

- (void)setSubViewsWithItemArray:(NSArray *)itemArray pageView:(NSArray *)pageViewArray parentVC:(UIViewController *)parentVC {
    __weak typeof(self)weakSelf = self;
    self.itemView = [[SegmentBarItem alloc]initWithFrame:CGRectMake(0, 0, CGRectGetWidth(self.frame), ITEMHEIGHT)];
    self.itemView.dataSource = itemArray;
    self.itemView.selectBlock = ^(NSInteger selectIndex) {
        weakSelf.scrollview.contentOffset = CGPointMake(CGRectGetWidth(self.frame) * selectIndex, 0);
        if (weakSelf.segmentBlock) {
            weakSelf.segmentBlock(selectIndex);
            weakSelf.index = selectIndex;
        }
        [weakSelf.homeCategoryBtnView setSubViewController:pageViewArray[selectIndex]];
    };
    [self addSubview:self.itemView];

    self.scrollview = [[SegMainScrollView alloc]initWithFrame:CGRectMake(0, ITEMHEIGHT + CategoryHEIGHT, CGRectGetWidth(self.frame), CGRectGetHeight(self.frame) - ITEMHEIGHT - CategoryHEIGHT)];
    self.scrollview.delegate = self;
    self.scrollview.pagingEnabled = YES;
    self.scrollview.backgroundColor = [UIColor whiteColor];
    self.scrollview.contentSize = CGSizeMake(itemArray.count * CGRectGetWidth(self.frame), CGRectGetWidth(self.frame));
    for (NSInteger j = 0; j < pageViewArray.count; j++) {
        UIViewController *subVC = pageViewArray[j];
        subVC.view.bounds = CGRectMake(0, CategoryHEIGHT, CGRectGetWidth(self.scrollview.frame), CGRectGetHeight(self.scrollview.frame));
        subVC.view.y = 0;
        subVC.view.x = CGRectGetWidth(self.scrollview.frame) * j;
        [self.scrollview addSubview:subVC.view];
        [parentVC addChildViewController:subVC];
    }
    self.scrollview.contentOffset = CGPointMake(0, 0);
    
    [self addSubview:self.homeCategoryBtnView];
    
    [self addSubview:self.scrollview];
}

- (NSMutableArray *)vcArr {
    if(_vcArr == nil) {
        _vcArr = [NSMutableArray array];
    }
    return _vcArr;
}

- (HomeCategoryBtnView *)homeCategoryBtnView {
    if(_homeCategoryBtnView == nil) {
        _homeCategoryBtnView = [[HomeCategoryBtnView alloc]initWithFrame:CGRectMake(0, ITEMHEIGHT, CGRectGetWidth(self.frame), CategoryHEIGHT)];
    }
    return _homeCategoryBtnView;
}

- (void)setFirstSelectPage:(NSInteger)firstSelectPage {
    _firstSelectPage = firstSelectPage;
    self.itemView.selectPage = firstSelectPage;
    self.scrollview.contentOffset = CGPointMake(CGRectGetWidth(self.frame)*firstSelectPage, 0);
    [self.homeCategoryBtnView setSubViewController:self.vcArr[firstSelectPage]];
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    self.startOffsetx = scrollView.contentOffset.x;
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    if (scrollView == self.scrollview) {
        NSInteger page = scrollView.contentOffset.x / CGRectGetWidth(self.frame);
        CGFloat currentOffsetx = scrollView.contentOffset.x;
        if (currentOffsetx > self.startOffsetx) {//往左
            self.itemView.selectPage = page;
            [self.homeCategoryBtnView setSubViewController:self.vcArr[page]];
        } else if (currentOffsetx < self.startOffsetx) {//右
            CGFloat dragWidth = self.startOffsetx - currentOffsetx;
            if (dragWidth > CGRectGetWidth(self.frame) / 2) {//是否划过页面一半位置
                self.itemView.selectPage = page;
                [self.homeCategoryBtnView setSubViewController:self.vcArr[page]];
            }
        }
    }
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    if (scrollView == self.scrollview) {
        NSInteger page = scrollView.contentOffset.x / CGRectGetWidth(self.frame);
        self.itemView.selectPage = page;
        if (self.segmentBlock) {
            self.segmentBlock(page);
            self.index = page;
        }
    }
}

@end
