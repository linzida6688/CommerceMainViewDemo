//
//  SegMainScrollView.m
//  HG_ShoppingMall
//
//  Created by Lindashuai on 2019/12/9.
//  Copyright © 2019 Lindashuai. All rights reserved.
//

#import "SegMainScrollView.h"

@implementation SegMainScrollView

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {
    return NO;
}

@end
