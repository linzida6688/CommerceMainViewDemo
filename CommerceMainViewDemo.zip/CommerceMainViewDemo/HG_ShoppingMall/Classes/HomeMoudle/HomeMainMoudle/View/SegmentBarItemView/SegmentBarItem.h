//
//  SegmentItem.h
//  InstrumentPro
//
//  Created by 浅佳科技 on 2018/12/28.
//  Copyright © 2018年 KuaiZhunCheFu. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^SelectItemBlock)(NSInteger selectIndex);
@interface SegmentBarItem : UIView

@property(nonatomic, copy) NSArray *dataSource;
@property(nonatomic, copy) UIColor *bgColor;
@property(nonatomic, assign) NSInteger selectPage;
@property(nonatomic, copy) SelectItemBlock selectBlock;

@end
