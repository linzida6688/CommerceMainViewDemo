//
//  SegmentView.h
//  InstrumentPro
//
//  Created by 浅佳科技 on 2018/12/28.
//  Copyright © 2018年 KuaiZhunCheFu. All rights reserved.
//

#import <UIKit/UIKit.h>
@class SegMainScrollView;
typedef void(^SegmentBlock)(NSInteger selectIndex);
@interface SegmentView : UIView

/*
 * itemArray  item title数组
 * pageViewArray  vc数组
 */
- (instancetype)initWithFrame:(CGRect)frame
                       items:(NSArray *)itemArray
                    pageView:(NSArray *)pageViewArray
                    parentVC:(UIViewController *)parentVC;

@property(nonatomic, strong) SegMainScrollView *scrollview;

//回调
@property (copy ,nonatomic) SegmentBlock segmentBlock;

//首次选择的item
@property (assign, nonatomic) NSInteger firstSelectPage;

@property (assign, nonatomic) NSInteger index;

@end
