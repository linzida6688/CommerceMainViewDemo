//
//  SegmentItem.m
//  InstrumentPro
//
//  Created by 浅佳科技 on 2018/12/28.
//  Copyright © 2018年 KuaiZhunCheFu. All rights reserved.
//

#import "SegmentBarItem.h"
#import "SegItem.h"

#if __has_include("SizeHeader.h")
#import "SizeHeader.h"
#define kViewHeader 1
#endif

static NSString *const kSegItemCell = @"kSegItemCell";
@interface SegmentBarItem () <UITableViewDelegate,UITableViewDataSource>
@property(nonatomic, strong) UITableView *tabView;
@end

@implementation SegmentBarItem

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        self.transform = CGAffineTransformMakeRotation(- M_PI_2);//横向滚动
        [self addSubview:self.tabView];
    }
    return self;
}

- (void)setFrame:(CGRect)frame {
    frame.size.height = CGRectGetWidth(self.frame);
    frame.size.width = CGRectGetHeight(self.frame);
    frame.origin.x = - CGRectGetHeight(self.frame) / 2 + CGRectGetWidth(self.frame) / 2;
    frame.origin.y = - CGRectGetWidth(self.frame) / 2 + CGRectGetHeight(self.frame) / 2;
    [super setFrame:frame];
}

//刷新数据
- (void)setDataSource:(NSArray *)dataSource {
    _dataSource = dataSource;
    [self.tabView reloadData];
}

- (UITableView *)tabView {
    if (_tabView == nil) {
        _tabView = [[UITableView alloc] initWithFrame:self.bounds style:UITableViewStylePlain];
        _tabView.estimatedSectionFooterHeight = 0;
        _tabView.estimatedSectionHeaderHeight = 0;
        _tabView.delegate = self;
        _tabView.dataSource = self;
        _tabView.showsVerticalScrollIndicator = NO;
        _tabView.estimatedRowHeight = 0;
        _tabView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tabView.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
        [_tabView registerNib:[UINib nibWithNibName:NSStringFromClass([SegItem class]) bundle:nil] forCellReuseIdentifier:kSegItemCell];
    }
    return _tabView;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataSource.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    CGFloat totalLength = [self widthForlabelWithHeight:CGRectGetHeight(self.frame) fontSize:15 Content:[self.dataSource componentsJoinedByString:@""]];
    if ((totalLength + self.dataSource.count * 24) < CGRectGetWidth(self.frame)) {
        return CGRectGetWidth(self.frame) / self.dataSource.count;
    }else{
        CGFloat itemWidth = [self widthForlabelWithHeight:CGRectGetWidth(self.frame) fontSize:15 Content:self.dataSource[indexPath.row]];
        return itemWidth + 24;
    }
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    SegItem *cell = [tableView dequeueReusableCellWithIdentifier:kSegItemCell forIndexPath:indexPath];
    cell.backgroundColor = [UIColor whiteColor];
    cell.transform = CGAffineTransformMakeRotation(M_PI_2);
    cell.titleLabel.text = self.dataSource[indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    if (indexPath.row == self.selectPage) {
#ifdef kViewHeader
        cell.bottomLine.backgroundColor = LY_Color_Hex(#F7473F);
        cell.titleLabel.textColor = LY_Color_Hex(#F7473F);
#else
        cell.bottomLine.backgroundColor = [UIColor redColor];
        cell.titleLabel.textColor = [UIColor redColor];
#endif
        [UIView animateWithDuration:1.0f animations:^{
            cell.titleLabel.font = [UIFont systemFontOfSize:16];
        }];
    } else {
#ifdef kViewHeader
        cell.titleLabel.textColor = LY_Color_Hex(#666666);
#else
        cell.titleLabel.textColor = [UIColor blackColor];
#endif
        cell.bottomLine.backgroundColor = [UIColor clearColor];
        [UIView animateWithDuration:1.0f animations:^{
            cell.titleLabel.font = [UIFont systemFontOfSize:15];
        }];
    }
    CGFloat itemWidth = [self widthForlabelWithHeight:CGRectGetWidth(self.frame) fontSize:15 Content:self.dataSource[indexPath.row]];
    cell.bottomLineWidth.constant = itemWidth;
    return cell;
}

//item点击
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    self.selectPage = indexPath.row;
    [tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
    self.selectBlock(indexPath.row);
    [tableView reloadData];
}

- (void)setSelectPage:(NSInteger)selectPage {
    _selectPage = selectPage;
    NSIndexPath *indexpath = [NSIndexPath indexPathForRow:selectPage inSection:0];
    [self.tabView scrollToRowAtIndexPath:indexpath atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
    [_tabView reloadData];
}

- (CGFloat)widthForlabelWithHeight:(CGFloat)height fontSize:(CGFloat)fontSize Content:(nonnull NSString *)content {
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 0, height)];
    label.font = [UIFont systemFontOfSize:fontSize];
    label.text = content;
    [label sizeToFit];
    return label.frame.size.width;
}

@end
