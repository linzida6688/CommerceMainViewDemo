//
//  HomeHeaderRefresh.h
//  HG_ShoppingMall
//
//  Created by Lindashuai on 2020/11/23.
//  Copyright © 2020 Lindashuai. All rights reserved.
//

#import "MJRefreshNormalHeader.h"

NS_ASSUME_NONNULL_BEGIN

@interface HomeHeaderRefresh : MJRefreshNormalHeader

@end

NS_ASSUME_NONNULL_END
