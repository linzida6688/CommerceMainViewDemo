//
//  LoginViewController.m
//  HG_ShoppingMall
//
//  Created by Lindashuai on 2019/11/25.
//  Copyright © 2019 Lindashuai. All rights reserved.
//

#import "LoginViewController.h"
#import "LoginMainView.h"

#import "HomeViewController.h"

@interface LoginViewController () <UIGestureRecognizerDelegate,LoginMainViewDelegate>

@end

@implementation LoginViewController

#pragma mark - 禁止右滑返回

- (void)viewDidAppear:(BOOL)animated{
    self.navigationController.interactivePopGestureRecognizer.delegate = self;
}
- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer{
    return NO;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    [self setTopTitle:@"首页"];
    
    //setUI
    [self setUI];
    [self createTabbar];
}

- (void)setUI
{
    LoginMainView *loginMainView = [[LoginMainView alloc]initWithFrame:CGRectZero];
    loginMainView.delegate = self;
    [self.view addSubview:loginMainView];
}


#pragma mark - delegate跳转忘记密码界面

- (void)btnFogiveActionOfDelegate {
//    ForgiveViewController *forgiveVC = [[ForgiveViewController alloc]init];
//    forgiveVC.mainTitleInView = @"修改密码";
//    forgiveVC.rightTitleInView = @"确认修改";
//    forgiveVC.type = ForgiveViewControllerType_ForgivePassW;
//    [[BaseNavigationManager shareInstance].NavigationController pushViewController:forgiveVC animated:YES];
}

#pragma mark - delegate跳转主界面

- (void)btnLoginActionAccountText:(NSString *)accountText passWordText:(NSString *)passWordText
{
    //    if([accountText isEqualToString:@"123"] && [passWordText isEqualToString:@"123"]) {
    //
    //    } else {
    //        DSToast *toast = [[DSToast alloc]initWithText:@"请输入正确账号和密码"];
    //        [toast showInView:self.view];
    //    }
    [self createTabbar];
}

#pragma mark - 创建标签栏视图

- (void)createTabbar
{
    //0
    HomeViewController *home = [HomeViewController new];
    home.tabBarItem.title = @"首页";
    home.tabBarItem.image = [[UIImage imageNamed:@"Home_selectImage"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    home.tabBarItem.selectedImage = [[UIImage imageNamed:@"Home_normalImage"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    UINavigationController *nav1 = [[UINavigationController alloc]initWithRootViewController:home];
    nav1.navigationBar.hidden = YES;
    
    UITabBarController *tabbar = [[UITabBarController alloc]init];
    //tabbar.ba
    tabbar.viewControllers = [NSArray arrayWithObjects:nav1, nil];
    tabbar.selectedIndex = 0;
    [[UITabBarItem appearance]setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:MAIN_COLOR,NSForegroundColorAttributeName,nil]forState:UIControlStateSelected];
    //使用单例进行出入栈跳转
    [[BaseNavigationManager shareInstance].NavigationController pushViewController:tabbar animated:NO];
}

@end

