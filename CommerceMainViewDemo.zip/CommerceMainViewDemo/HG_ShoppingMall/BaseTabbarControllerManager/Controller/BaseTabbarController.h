//
//  BaseTabbarViewController.h
//  YM_Installment
//
//  Created by Lindashuai on 2019/10/26.
//  Copyright © 2019 Lindashuai. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseTabbarController : UITabBarController

- (void)setTabbarControllerColor:(UIColor *)backColor;

@end
