//
//  BaseTabbarViewController.m
//  YM_Installment
//
//  Created by Lindashuai on 2019/10/26.
//  Copyright © 2019 Lindashuai. All rights reserved.
//

#import "BaseTabbarController.h"

@interface BaseTabbarController ()

@end

@implementation BaseTabbarController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

- (void)setTabbarControllerColor:(UIColor *)backColor {
    self.tabBar.barTintColor = backColor;
}

@end
